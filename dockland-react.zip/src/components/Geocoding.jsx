import React, { useState } from 'react';
import axios from 'axios';
import { Input, Button, FormControl, FormLabel, Box, VStack, Text } from '@chakra-ui/react';

const Geocoding = () => {
  const [address, setAddress] = useState('');
  const [coordinates, setCoordinates] = useState(null);
  const [error, setError] = useState('');

  const handleInputChange = (e) => {
    setAddress(e.target.value);
  };

  const getCoordinates = async () => {
    try {
      const response = await axios.get('https://maps.googleapis.com/maps/api/geocode/json', {
        params: {
          address: address,
          key: 'YOUR_GOOGLE_MAPS_API_KEY', // Replace with your actual API key
        },
      });

      if (response.data.status === 'OK') {
        const location = response.data.results[0].geometry.location;
        setCoordinates(location);
        setError('');
      } else {
        setError('Unable to find the location. Please try again.');
      }
    } catch (error) {
      setError('An error occurred while fetching the data. Please try again.');
    }
  };

  return (
    <Box mt={4} p={4} bg="gray.100" borderRadius="md" shadow="md">
      <VStack spacing={4}>
        <FormControl id="address" isRequired>
          <FormLabel>Enter Home Address</FormLabel>
          <Input name="address" value={address} onChange={handleInputChange} placeholder="e.g., 1600 Amphitheatre Parkway, Mountain View, CA" />
        </FormControl>
        <Button colorScheme="blue" onClick={getCoordinates}>
          Get Coordinates
        </Button>
        {coordinates && (
          <Box mt={4} p={4} bg="white" borderRadius="md" shadow="md">
            <Text><strong>Latitude:</strong> {coordinates.lat}</Text>
            <Text><strong>Longitude:</strong> {coordinates.lng}</Text>
          </Box>
        )}
        {error && (
          <Text color="red.500">{error}</Text>
        )}
      </VStack>
    </Box>
  );
};

export default Geocoding;
